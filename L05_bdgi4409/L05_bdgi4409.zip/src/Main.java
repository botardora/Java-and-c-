public class Main {
    public static void main(String[] args) {
        ColorFrame frame1 = new ColorFrame();
        TextFilterFrame frame2 = new TextFilterFrame();
        GroceryListFrame frame3 = new GroceryListFrame();
    }
}