package lab8;

public interface Plant {
    public double getOxigenAmountPerYear();
    public int getLifeTime();
    public String getRepresentation();
}
