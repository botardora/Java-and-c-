
import core.Car;
import collection.CarList;
public class TestCarList {
    public static void main(String[] args) {
        CarList carList = new CarList(4); //megadjuk hany auto szerepelhet a listaban
        Car car1 = new Car("Sedan", 5, 200);
        Car car2 = new Car("SUV", 3, 250);
        Car car3 = new Car("Convertible", 2, 300);
        Car car4 = new Car("Sports", 7,500);
        car4.setAge(5); //ezzel most felulirom az elobb megadottakat
        car4.setType("Beetle");
        car4.setPerformance(150);
        //car4.getAge();
        //car4.getType();
        //car4.getPerformance();
        Car car5 = new Car("Cabrio", 4, 300); //plusz egy, hogy latsszon a kivetelkezeles
        //System.out.println(car1);
        //System.out.println(car2);
        //System.out.println(car3);
        carList.addCar(car1);
        carList.addCar(car2);
        carList.addCar(car3);
        carList.addCar(car4);
        carList.addCar(car5);

        CarList.CarIterator iterator = carList.getIterator();

        while (iterator.hasMoreElements()) {
            Car car = iterator.nextElement();
            System.out.println(car);
        }
    }
}