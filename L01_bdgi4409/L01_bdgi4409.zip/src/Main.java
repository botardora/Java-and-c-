public class Main {
    public static void main(String[] args) {
        //1.
        String nev = args[0];
        System.out.println("Hello " + nev + "!");
        //System.out.println("Hello " + args[0] + "!"); ez maskepp
    }
}