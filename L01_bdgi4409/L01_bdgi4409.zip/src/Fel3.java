public class Fel3 {
    public static void main(String[] args) {
        //3.

        for (String arg : args) { //vegigvesszuk a paranccsori argumentumokat
                    char betu = arg.charAt(0);
                    //char atalakitott;
                    if (Character.isUpperCase(betu)) {
                        System.out.println(Character.toLowerCase(betu));
                    } else if (Character.isLowerCase(betu)) {
                        System.out.println(Character.toUpperCase(betu));
                    } else {
                        System.out.println(betu); //haa valami nem betu az ugyanolyan marad
                    }
                }
        }
    }
