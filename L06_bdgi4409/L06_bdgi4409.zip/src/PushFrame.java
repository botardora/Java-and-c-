import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Random;

public class PushFrame extends JFrame {
    private JButton gomb = new JButton("Push me!");
    private Random r;
    public PushFrame(){
        setTitle("Nyomd meg a gombot!");
        setBounds(200,200,400,400);
        setLayout(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setMinimumSize(new Dimension(300,300));
        this.add(gomb,BOTTOM_ALIGNMENT);
        Dimension d = gomb.getPreferredSize();
        gomb.setBounds(100,100,d.width,d.height); //gomb kezdeti helyzete es merete
        //add(gomb);

        r = new Random();
        gomb.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {

            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {
                int x= r.nextInt(getContentPane().getWidth() - d.width); //veletlenszeru koordinatak
                int y=r.nextInt(getContentPane().getHeight() - d.height);
                int newx=e.getX()+gomb.getX(); //aktualis egerpzicio
                int newy=e.getY()+gomb.getY();
                while (x < newx && newx < (x + d.width) && y < newy && newy < y + d.height) { //biztositja, hogy az uj koordinatak ne fedjek a teruletet ahol az eger van
                    x = r.nextInt(getContentPane().getWidth() - d.width);
                    y = r.nextInt(getContentPane().getHeight() - d.height);
                }
                gomb.setBounds(x, y, d.width, d.height); //a gomb hatarai beallitodnak az uj poziciora
            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });


        setVisible(true);
    }
}
