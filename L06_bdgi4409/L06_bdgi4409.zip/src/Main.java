public class Main {
    public static void main(String[] args) {
        DateFrame frame = new DateFrame();
        MoveCircleFrame frame1 = new MoveCircleFrame();
        PushFrame frame2 = new PushFrame();
    }
}