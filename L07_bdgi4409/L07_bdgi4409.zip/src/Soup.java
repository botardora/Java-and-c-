public interface Soup {
    public String toString();
    public void associateMainDish(MainDish mainDish);
}
