public class ChickpeaCurry implements MainDish{
    @Override
    public String toString() {
        return "ChickpeaCurry";
    }
}
