public interface MainDish {
    public String toString();
}
