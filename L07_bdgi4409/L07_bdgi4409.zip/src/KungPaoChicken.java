public class KungPaoChicken implements MainDish{
    @Override
    public String toString() {
        return "KungPaoChicken";
    }
}
